import 'package:cloud_firestore/cloud_firestore.dart';

final dummySnapshot = [
  {"name": "Lilian", "votes": 20},
  {"name": "Lili", "votes": 14},
  {"name": "Lil", "votes": 11},
  {"name": "Lin", "votes": 4},
  {"name": "L", "votes": 1},
];

class Names {
  final String name;
  final int votes;
  final DocumentReference reference;

  Names.fromMap(Map<String, dynamic> map, {this.reference})
      : assert(map['name'] != null),
        assert(map['votes'] != null),
        name = map['name'],
        votes = map['votes'];

  Names.fromSnapshot(DocumentSnapshot snapshot)
      : this.fromMap(snapshot.data, reference: snapshot.reference);

  @override
  String toString() => "Record<$name:$votes>";
}
